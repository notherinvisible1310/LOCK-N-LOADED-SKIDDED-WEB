var dropdown = document.getElementById("openMenu");
var menuShow = document.getElementById("navbarMenuHeroC");

dropdown.addEventListener("click", function () {
  menuShow.classList.toggle("is-active");
});
